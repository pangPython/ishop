<!-- 页脚开始 -->
<div class="footer mt20">
<script type="text/javascript" src="./js/juicer.js"></script>
</body></html>
<?php
include 'db_close.php';
 ?>
